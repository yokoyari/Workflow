#!/usr/bin/env node

import readline from "readline";
import { execSync } from "child_process";
import fs from "fs";

let iteration = 0;
const MAX = 10;

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

/**
 * MCP protocol: read JSON lines from stdin, write JSON to stdout
 */
rl.on("line", (line) => {
    const req = JSON.parse(line);

    if (req.method === "run") {
        iteration++;

        let testOutput = "";
        try {
            testOutput = execSync("npm test", { encoding: "utf-8" });
        } catch (e) {
            testOutput = e.stdout?.toString() || e.message;
        }

        const done =
            iteration >= MAX ||
            testOutput.includes("PASS") ||
            testOutput.includes("passing");

        const response = {
            iteration,
            done,
            observation: testOutput.slice(-2000), // 給 Claude 看測試結果
            instruction: done
                ? "All tests passed. Output exactly SRK_DONE."
                : "Fix the failing tests, review your changes, then run tests again."
        };

        process.stdout.write(JSON.stringify(response) + "\n");
    }
});
