# Execution Policy

## Execution Modes

### 1. SAFE_AUTORUN
适用于：
- 本地开发
- 前端浏览器检查
- 单元测试
- 可重复、可回滚操作

规则：
- Agent 可直接执行
- 无需逐条人类确认
- 必须完整报告执行结果

---

### 2. CONFIRM_BEFORE_RUN
适用于：
- 数据迁移
- 生产配置变更
- 不可逆操作

规则：
- 每一步必须人类确认
- 默认阻塞

---

## Default Mapping

- Frontend browser MCP checks → SAFE_AUTORUN
- Local backend run → SAFE_AUTORUN
- Test execution → SAFE_AUTORUN
- Production deploy → CONFIRM_BEFORE_RUN
