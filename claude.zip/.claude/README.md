# .claude Engineering Governance

This directory defines the governance system for AI-assisted development.

---

## Priority Order

1. constraints.md
2. execution-policy.md
3. workflow.md
4. agent role definitions

---

## Role Structure

### Engineering
- Architect
- Implementer
- Reviewer
- Test Designer

### Data
- Database Designer

The Database Designer participates ONLY in DESIGN stage
and is responsible for all data modeling decisions.

---

## Feature Lifecycle

Feature instances are stored in `.claude/features/`.

They represent concrete executions of `workflow.md`.

Do NOT place feature lifecycle files in project root.
