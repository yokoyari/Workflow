# Feature Lifecycle (AI-Governed)

## 定位
- Feature 文件是 **workflow 的实例**
- workflow 是 **唯一合法流程**
- agents 只在自己的 section 内行动

---

## 强制规则

1. 每个功能必须对应一个 feature 文件（基于 template）
2. Status 字段必须与 `.claude/workflow.md` 状态一致
3. 任一 agent 只能编辑自己负责的 section
4. 状态变更必须由人类明确确认

---

## 禁止事项

- 禁止在对话中“口头推进状态”
- 禁止跳过 DESIGN
- 禁止在 REVIEW / TEST 阶段修改实现
