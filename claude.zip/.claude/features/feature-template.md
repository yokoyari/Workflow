# Feature: <Feature Name>

## 0. Meta
- Status: DESIGN | IMPLEMENT | REVIEW | TEST | DONE
- Priority: High | Medium | Low
- Risk Level: Low | Medium | High

---

## 1. Problem Statement (PM)
- 这个功能要解决什么问题？
- 不做会有什么明确损失？

---

## 2. Success Criteria (PM)
- 成功的客观标准是什么？
- 如何验证（必须可测试 / 可判断）？

---

## 3. Design (Architect)
- Context analysis（现状 & 约束）
- Design options（至少 2 个）
- Trade-offs（优缺点）
- Recommended option（必须明确）

⛔ 未经人类确认，不得进入 IMPLEMENT

---

## 4. Implementation Plan (Implementer)
- Affected files（明确文件）
- Minimal change strategy
- Migration / Rollback（如适用）

⛔ 禁止实现未被 DESIGN 批准的内容

---

## 5. Review Checklist (Reviewer)
- [ ] 是否违反 `.claude/constraints.md`
- [ ] 是否引入隐藏耦合
- [ ] 是否破坏可维护性
- [ ] 是否存在未来演进风险

---

## 6. Test Plan (Test Designer)
- 核心用例
- 边界条件
- 失败路径 / 异常行为

---

## 7. Final Outcome
- Result: PASS | FAIL | BLOCKED
- Notes:
