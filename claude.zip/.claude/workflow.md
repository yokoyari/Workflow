# Engineering Workflow (AI-Governed)

This document defines the mandatory execution workflow.
It governs HOW work proceeds, not WHAT to build.

---

## Governing Document Priority

1. constraints.md            (Supreme Law)
2. workflow.md               (Process & Authority)
3. decision-matrix.md        (Conflict Resolution)
4. agent role definitions

If conflict exists, higher priority wins.

---

## Core Rule

Execution priorities NEVER override design authority.

---

## State Machine

DESIGN → IMPLEMENT → REVIEW → TEST → DONE

Backward transitions allowed only as specified.

---

## STATE: DESIGN

**Roles Involved**
- Architect
- Database Designer (mandatory if persistent data exists)

**Execution Mode**
- NO_EXECUTION

### Responsibilities

#### Architect
- System boundaries
- Module structure
- Non-data technology stack
- Deployment shape (monolith / services / full-stack)

#### Database Designer
- Define core business data
- Decide data model stability boundaries
- Choose database technology
- Decide what is explicitly NOT designed yet

### Mandatory Outputs
- Architecture summary
- Data model decision (if applicable)
- Explicit list of deferred decisions

### Authority
- Data model decisions are FINAL and owned by Database Designer
- Schema decisions MUST NOT be revisited in later stages

### Exit Condition
- Human approval
- Feature state updated to IMPLEMENT

---

## STATE: IMPLEMENT

**Role**
- Implementer

**Execution Mode**
- SAFE_AUTORUN

### Responsibilities
- Implement strictly according to approved design
- Do NOT reinterpret schema or architecture
- Optimize only within approved boundaries

### Forbidden
- Schema changes
- Implicit data decisions
- Structural refactoring

---

## STATE: REVIEW

**Role**
- Reviewer

**Execution Mode**
- NO_EXECUTION

### Responsibilities
- Verify compliance with:
  - Approved architecture
  - Approved data model
  - constraints.md

### Outcomes
- PASS → TEST
- FAIL → IMPLEMENT

---

## STATE: TEST

**Role**
- Test Designer

**Execution Mode**
- SAFE_AUTORUN

### Responsibilities
- Validate correctness and assumptions
- Confirm no boundary violations

### Outcomes
- PASS → DONE
- FAIL → IMPLEMENT

---

## STATE: DONE

Feature is complete.
No further modification allowed.
New requirements require new feature lifecycle.
