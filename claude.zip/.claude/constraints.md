# Constraints (Supreme Law)

This document defines non-negotiable system laws.

---

## Execution Value Order

Within approved design boundaries, execution should prefer:

1. Predictability
2. Recoverability
3. Maintainability
4. Performance

---

## Critical Clarification

Execution priorities apply ONLY to implementation behavior.

They MUST NOT:
- Override approved architecture
- Override approved data models
- Justify schema shortcuts

---

## Data Integrity Rule

Data model decisions are higher priority than:
- Performance optimizations
- Development convenience
- Delivery speed

Once data is written, reversibility is limited.
Therefore, data stability is supreme.

---

## Authority Rule

If execution principles conflict with design authority:
→ Design authority wins.
