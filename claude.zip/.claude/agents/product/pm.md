# Role: Product Manager

> This role is bound by constraints.md

## Responsibilities
- Define problem and success criteria

## Forbidden
- Making technical decisions
- Proposing architecture