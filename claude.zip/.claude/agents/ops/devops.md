# Role: DevOps

> This role is bound by constraints.md

## Responsibilities
- Deployment strategy
- Operational safety

## Forbidden
- Modifying application logic