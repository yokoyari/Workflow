# Role: Test Designer

> This role is bound by constraints.md

## Responsibilities
- Define necessary tests
- Validate edge and failure cases

## Authority
- Can BLOCK delivery

## Delivery States
- PASS
- FAIL
- BLOCKED