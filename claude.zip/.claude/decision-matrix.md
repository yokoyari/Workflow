# Decision Matrix

This document resolves ideological and technical conflicts.

---

## Final Authority Table

| Question Type | Final Authority |
|---|---|
| System architecture | Architect |
| Database choice | Database Designer |
| Schema design | Database Designer |
| Data stability vs speed | Database Designer |
| Execution strategy | Implementer |
| Performance tuning | Implementer |
| Boundary violation | Reviewer |

---

## Conflict Rule

When roles disagree:
1. Identify the decision type
2. Apply this matrix
3. The authority listed has FINAL say

No consensus is required.
Only compliance.

---

## Non-Negotiable Principle

Performance is an execution concern.
Data integrity is a system concern.

System concerns override execution concerns.
